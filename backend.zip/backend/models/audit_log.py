from database.db import Database
import json

class AuditLog:
    def __init__(self, data):
        self.id = data.get('id')
        self.action = data.get('action')
        self.entity_type = data.get('entity_type')
        self.entity_id = data.get('entity_id')
        self.details = data.get('details')
        self.user_id = data.get('user_id')
        self.user_name = data.get('user_name')
        self.timestamp = data.get('timestamp')

    @staticmethod
    def get_db():
        return Database()

    @classmethod
    def create(cls, action, entity_type, entity_id, details, user_id=None, user_name=None):
        db = cls.get_db()
        
        if not user_name or user_name == 'System':
            from flask import request
            if hasattr(request, 'current_user') and request.current_user:
                user_name = request.current_user.name
                user_id = request.current_user.id
        
        # ⭐ Convert details to JSON string (required by the CHECK constraint)
        if isinstance(details, dict):
            details_json = json.dumps(details)
        else:
            # If it's a plain string, wrap it in a JSON object
            details_json = json.dumps({'message': str(details)})
        
        db.execute_query("""
            INSERT INTO audit_logs (action, entity_type, entity_id, details, user_id, user_name)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (action, entity_type, entity_id, details_json, user_id, user_name))
        return True

    @classmethod
    def find_all(cls, limit=100):
        db = cls.get_db()
        results = db.execute_query("""
            SELECT * FROM audit_logs 
            WHERE action NOT IN ('LOGIN', 'LOGOUT', 'USER_LOGOUT', 'USER_LOGOUT_ALL')
            ORDER BY timestamp DESC 
            LIMIT %s
        """, (limit,))
        return [cls(row) for row in results]

    def to_dict(self):
        # ⭐ Try to parse details as JSON
        details_value = self.details
        try:
            if isinstance(details_value, str):
                details_value = json.loads(details_value)
        except:
            pass
            
        return {
            'id': self.id,
            'action': self.action,
            'entityType': self.entity_type,
            'entityId': self.entity_id,
            'details': details_value,
            'userId': self.user_id,
            'userName': self.user_name,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None
        }